import frappe

from chromeis_sync.migration_audit.snapshot import SnapshotService
from chromeis_sync.migration_audit.repair import InvoiceRepair
from chromeis_sync.migration_audit.rebuild import InvoiceRebuilder
from chromeis_sync.migration_audit.verify import InvoiceVerifier
from chromeis_sync.migration_audit.models import RepairResult


class InvoiceTransaction:

    def __init__(self, invoice_name, target_currency):
        self.invoice_name = invoice_name
        self.target_currency = target_currency

    def execute(self):

        savepoint = self.invoice_name.replace("-", "_")

        print(f"\n===== {self.invoice_name} =====")

        snapshot = SnapshotService.create(self.invoice_name)

        frappe.db.savepoint(savepoint)

        try:

            repair = InvoiceRepair(self.invoice_name)

            repair.cancel()

            repair.release_whmcs_id()

            rebuilder = InvoiceRebuilder(
                snapshot,
                self.target_currency
            )

            new_invoice = rebuilder.build()

            verifier = InvoiceVerifier()

            verification = verifier.verify(
                snapshot,
                new_invoice,
                self.target_currency
            )

            if not verification.passed:
                raise Exception(
                    "\n".join(verification.errors)
                )

            frappe.db.commit()

            print("✓ Transaction Committed")

            return RepairResult(
                old_invoice=self.invoice_name,
                new_invoice=new_invoice.name,
                success=True,
                message="Verified"
            )

        except Exception as e:

            frappe.db.rollback(save_point=savepoint)

            print("✗ Transaction Rolled Back")

            return RepairResult(
                old_invoice=self.invoice_name,
                success=False,
                message=str(e)
            )
