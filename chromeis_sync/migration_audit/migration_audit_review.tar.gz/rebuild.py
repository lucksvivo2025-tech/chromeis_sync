import frappe


class InvoiceRebuilder:

    HEADER_FIELDS = [
        "customer",
        "customer_name",
        "company",
        "posting_date",
        "posting_time",
        "due_date",
        "currency",
        "debit_to",
        "cost_center",
        "remarks",
        "custom_whmcs_client_id",
        "whmcs_invoice_id",
        "update_outstanding_for_self"
    ]

    ITEM_FIELDS = [
        "item_code",
        "item_name",
        "description",
        "qty",
        "uom",
        "stock_uom",
        "conversion_factor",
        "rate",
        "income_account",
        "cost_center"
    ]

    def __init__(self, snapshot, target_currency):
        self.snapshot = snapshot
        self.target_currency = target_currency

    def build(self):

        old = self.snapshot["header"]

        inv = frappe.new_doc("Sales Invoice")

        # -------------------------
        # Header
        # -------------------------

        for field in self.HEADER_FIELDS:
            if field in old:
                inv.set(field, old[field])

        inv.currency = self.target_currency

        # -------------------------
        # Items
        # -------------------------


        for row in self.snapshot["items"]:

            item = {}

            for field in self.ITEM_FIELDS:
                if field in row:
                    item[field] = row[field]

            inv.append("items", item)

        inv.insert()

        inv.submit()

        return inv
